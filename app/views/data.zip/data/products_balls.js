/******************************************************************************
 Products - Balls data
===============================================================================

 Instructions for adding a new ball: 
 1) Save the image of the ball in the img/balls folder.
 2) Copy this segment of code

        {
            "image"         : "img/balls/<Ball Image File Name Here>",
            "description"   : "<Ball Name Here>"
        },

3) Paste it in the 'items' array of the respective brand.

===============================================================================

Instructions for adding a new brand:
1)  Save the image of the brand in the img/brands folder 
2)  Copy this segment of code

        {
            "brand"             : "<Brand Name Here>",
            "brandImage"        : "img/brands/<Brand Image File Name Here>",
            "items"             : []
        },

3)  Paste it in the 'balls' array.
4)  Follow the instructions for adding a new ball into the brand as mentioned
    above.

===============================================================================

For optimal performance
1)  Store images in JPEG format
2)  Brand images should be edited to width 150px
3)  Ball images should be edited to width 230px

******************************************************************************/

module.exports = {

    "balls": [
        {   
            "brand"             : "Ebonite",
            "brandImage"        : "img/brands/ebonite.jpg",
            "items"             : [
                {
                    "image"         : "img/balls/ebonitechampion.jpeg",
                    "description"   : "Champion"
                },
                {
                    "image"         : "img/balls/ebonitesource.png",
                    "description"   : "Source"
                },
            ]
        },
        {
            "brand"             : "Hammer",
            "brandImage"        : "img/brands/hammer.jpg",
            "items"             : [
                {
                    "image"         : "img/balls/blackwidowassassin.png",
                    "description"   : "Black Widow Assassin"
                },
                {
                    "image"         : "img/balls/deadlyaim.png",
                    "description"   : "Deadly Aim"
                },
            ]
        },
    ]
    
};